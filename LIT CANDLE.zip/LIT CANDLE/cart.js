// Shopping Cart Class
class ShoppingCart {
    constructor() {
        console.log('Initializing ShoppingCart');
        this.items = [];
        this.loadCart();
        this.updateCartCount();
        this.renderCart();
        this.attachCartEventListeners();
    }

    loadCart() {
        const savedCart = localStorage.getItem('cart');
        if (savedCart) {
            this.items = JSON.parse(savedCart);
            console.log('Loaded cart:', this.items);
        }
    }

    saveCart() {
        localStorage.setItem('cart', JSON.stringify(this.items));
        console.log('Saved cart:', this.items);
    }

    updateCartCount() {
        const cartCount = document.querySelector('.cart-count');
        if (cartCount) {
            const totalItems = this.items.reduce((sum, item) => sum + item.quantity, 0);
            cartCount.textContent = totalItems;
            console.log('Updated cart count:', totalItems);
        }
    }

    addToCart(product) {
        console.log('Adding to cart:', product);
        const existingItem = this.items.find(item => item.productId === product.id);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            this.items.push({
                productId: product.id,
                name: product.name,
                price: product.price,
                image: product.image,
                quantity: 1
            });
        }
        
        this.saveCart();
        this.updateCartCount();
        this.renderCart();
        this.showNotification('Item added to cart');
    }

    removeItem(productId) {
        console.log('Removing item:', productId);
        this.items = this.items.filter(item => item.productId !== productId);
        this.saveCart();
        this.updateCartCount();
        this.renderCart();
        this.showNotification('Item removed from cart');
    }

    updateQuantity(productId, newQuantity) {
        console.log('Updating quantity:', productId, newQuantity);
        const item = this.items.find(item => item.productId === productId);
        if (item) {
            if (newQuantity > 0) {
                item.quantity = newQuantity;
            } else {
                this.removeItem(productId);
            }
            this.saveCart();
            this.updateCartCount();
            this.renderCart();
        }
    }

    renderCart() {
        console.log('Rendering cart');
        const cartItems = document.querySelector('.cart-items');
        const cartSummary = document.querySelector('.cart-summary');
        
        if (!cartItems || !cartSummary) {
            console.log('Cart elements not found');
            return;
        }

        if (this.items.length === 0) {
            cartItems.innerHTML = `
                <div class="cart-empty">
                    <i class="fas fa-shopping-cart"></i>
                    <p>Your cart is empty</p>
                    <a href="shop.html" class="btn">Continue Shopping</a>
                </div>
            `;
            cartSummary.innerHTML = '';
            return;
        }

        // Render cart items
        cartItems.innerHTML = this.items.map(item => `
            <div class="cart-item" data-product-id="${item.productId}">
                <div class="cart-item-image">
                    <img src="${item.image}" alt="${item.name}">
                </div>
                <div class="cart-item-details">
                    <h3>${item.name}</h3>
                    <p class="price">$${item.price.toFixed(2)}</p>
                    <div class="quantity-controls">
                        <button class="quantity-btn minus" aria-label="Decrease quantity">-</button>
                        <input type="number" class="cart-item-quantity" value="${item.quantity}" min="1" aria-label="Item quantity">
                        <button class="quantity-btn plus" aria-label="Increase quantity">+</button>
                    </div>
                </div>
                <button class="remove-item" aria-label="Remove item">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `).join('');

        // Calculate totals
        const subtotal = this.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const shipping = subtotal > 0 ? 5.99 : 0;
        const total = subtotal + shipping;

        // Render cart summary
        cartSummary.innerHTML = `
            <div class="summary-header">
                <h2>Order Summary</h2>
            </div>
            <div class="summary-details">
                <div class="summary-row">
                    <span>Subtotal</span>
                    <span>$${subtotal.toFixed(2)}</span>
                </div>
                <div class="summary-row">
                    <span>Shipping</span>
                    <span>$${shipping.toFixed(2)}</span>
                </div>
                <div class="summary-row total">
                    <span>Total</span>
                    <span>$${total.toFixed(2)}</span>
                </div>
            </div>
            <button class="checkout-btn" ${this.items.length === 0 ? 'disabled' : ''}>
                Proceed to Checkout
            </button>
        `;

        this.attachCartEventListeners();
    }

    attachCartEventListeners() {
        console.log('Attaching cart event listeners');
        
        // Remove buttons
        document.querySelectorAll('.remove-item').forEach(button => {
            button.addEventListener('click', (e) => {
                console.log('Remove button clicked');
                const cartItem = e.target.closest('.cart-item');
                if (cartItem) {
                    const productId = cartItem.dataset.productId;
                    console.log('Removing product:', productId);
                    this.removeItem(productId);
                }
            });
        });

        // Quantity controls
        document.querySelectorAll('.cart-item-quantity').forEach(input => {
            input.addEventListener('change', (e) => {
                console.log('Quantity changed');
                const cartItem = e.target.closest('.cart-item');
                if (cartItem) {
                    const productId = cartItem.dataset.productId;
                    const newQuantity = parseInt(e.target.value);
                    console.log('Updating quantity for product:', productId, 'to', newQuantity);
                    this.updateQuantity(productId, newQuantity);
                }
            });
        });

        // Plus/Minus buttons
        document.querySelectorAll('.quantity-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                console.log('Quantity button clicked');
                const cartItem = e.target.closest('.cart-item');
                if (cartItem) {
                    const input = cartItem.querySelector('.cart-item-quantity');
                    const productId = cartItem.dataset.productId;
                    const currentValue = parseInt(input.value);
                    
                    if (e.target.classList.contains('plus')) {
                        input.value = currentValue + 1;
                    } else if (e.target.classList.contains('minus')) {
                        input.value = Math.max(1, currentValue - 1);
                    }
                    
                    console.log('Updating quantity for product:', productId, 'to', input.value);
                    this.updateQuantity(productId, parseInt(input.value));
                }
            });
        });
    }

    showNotification(message) {
        console.log('Showing notification:', message);
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
}

// Initialize cart when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing cart');
    window.cart = new ShoppingCart();
});

// Add to cart buttons
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('add-to-cart')) {
        console.log('Add to cart button clicked');
        const productCard = e.target.closest('.product-card');
        if (productCard) {
            const product = {
                id: productCard.dataset.productId,
                name: productCard.querySelector('h3').textContent,
                price: parseFloat(productCard.dataset.price),
                image: productCard.querySelector('img').src
            };
            console.log('Adding product to cart:', product);
            window.cart.addToCart(product);
        }
    }
});

// Scroll to top button
const scrollTopBtn = document.querySelector('.scroll-top');
if (scrollTopBtn) {
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 100) {
            scrollTopBtn.classList.add('show');
        } else {
            scrollTopBtn.classList.remove('show');
        }
    });

    scrollTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
} 